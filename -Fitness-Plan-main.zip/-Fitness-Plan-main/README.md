# FitBuddy – AI Fitness Plan Generator

An AI-powered fitness web app using **FastAPI** + **Google Gemini** that generates personalized 7-day workout plans and nutrition tips.

## Project Structure
```
fitbuddy/
├── requirements.txt
├── .env.example
├── app/
│   ├── main.py                    # FastAPI entry point
│   ├── routes.py                  # All route handlers
│   ├── database.py                # SQLAlchemy models & DB logic
│   ├── schemas.py                 # Pydantic validation models
│   ├── gemini_generator.py        # Gemini Pro – workout plan
│   ├── gemini_flash_generator.py  # Gemini Flash – nutrition tips
│   ├── updated_plan.py            # Feedback-based plan updater
│   ├── templates/
│   │   ├── index.html             # User input form
│   │   ├── result.html            # Workout plan + feedback
│   │   └── all_users.html         # Admin dashboard
│   └── static/
│       └── images/
└── fitbuddy.db                    # Auto-generated SQLite DB
```

## Setup & Run

1. **Clone and enter directory**
   ```bash
   cd fitbuddy
   ```

2. **Create virtual environment**
   ```bash
   python -m venv venv
   venv\Scripts\activate        # Windows
   source venv/bin/activate     # Mac/Linux
   ```

3. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

4. **Set your Gemini API key**
   ```bash
   copy .env.example .env       # Windows
   cp .env.example .env         # Mac/Linux
   # Edit .env and add your GOOGLE_API_KEY
   ```

5. **Run the server**
   ```bash
   uvicorn app.main:app --reload
   ```

6. **Open in browser**
   - App: http://127.0.0.1:8000
   - API Docs: http://127.0.0.1:8000/docs

## Features
- 7-day personalized workout plan via Gemini 1.5 Pro
- Nutrition tips via Gemini Flash
- Feedback-based plan updates
- Admin dashboard for all users
- SQLite persistent storage
