from google import genai
import os
from dotenv import load_dotenv

load_dotenv()
client = genai.Client(api_key=os.getenv("GOOGLE_API_KEY"))

def update_workout_plan(original_plan: str, feedback: str) -> str:
    prompt = f"""
    Here is an existing 7-day workout plan:
    {original_plan}

    The user feedback:
    {feedback}

    Please update the plan based on feedback while keeping the 7-day structure 
    with warm-up, main workout, and cooldown for each day.
    """
    response = client.models.generate_content(
        model="gemini-2.0-flash", contents=prompt
    )
    return response.text