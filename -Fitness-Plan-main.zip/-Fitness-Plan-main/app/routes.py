import os
from fastapi import APIRouter, Form, Request, Depends
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy.orm import Session

from app.database import get_db, save_user, save_plan, update_plan, get_user, get_original_plan, get_all_users
from app.gemini_generator import generate_workout_gemini
from app.gemini_flash_generator import generate_nutrition_tip_with_flash
from app.updated_plan import update_workout_plan

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
TEMPLATE_DIR = os.path.join(BASE_DIR, "templates")

router = APIRouter()
templates = Jinja2Templates(directory=TEMPLATE_DIR)


@router.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


@router.post("/generate-workout", response_class=HTMLResponse)
def generate_workout(
    request: Request,
    name: str = Form(...),
    user_id: str = Form(...),
    age: int = Form(...),
    weight: float = Form(...),
    goal: str = Form(...),
    intensity: str = Form(...),
    db: Session = Depends(get_db)
):
    user = save_user(db, user_id, name, age, weight, goal, intensity)
    workout_plan = generate_workout_gemini(goal, intensity)
    nutrition_tip = generate_nutrition_tip_with_flash(goal)
    save_plan(db, user_id, workout_plan)

    return templates.TemplateResponse("result.html", {
        "request": request,
        "user": user,
        "workout_plan": workout_plan,
        "nutrition_tip": nutrition_tip,
        "updated_plan": None,
        "feedback_success": False
    })


@router.post("/submit-feedback", response_class=HTMLResponse)
def submit_feedback(
    request: Request,
    user_id: str = Form(...),
    feedback: str = Form(...),
    db: Session = Depends(get_db)
):
    user = get_user(db, user_id)
    original_plan = get_original_plan(db, user_id)

    if not user or not original_plan:
        return templates.TemplateResponse("index.html", {
            "request": request,
            "error": "User ID not found. Please generate a plan first."
        })

    new_plan = update_workout_plan(original_plan, feedback)
    nutrition_tip = generate_nutrition_tip_with_flash(user.goal)
    update_plan(db, user_id, new_plan)

    return templates.TemplateResponse("result.html", {
        "request": request,
        "user": user,
        "workout_plan": original_plan,
        "nutrition_tip": nutrition_tip,
        "updated_plan": new_plan,
        "feedback_success": True
    })


@router.get("/view-all-users", response_class=HTMLResponse)
def view_all_users(request: Request, db: Session = Depends(get_db)):
    users = get_all_users(db)
    return templates.TemplateResponse("all_users.html", {
        "request": request,
        "users": users
    })
