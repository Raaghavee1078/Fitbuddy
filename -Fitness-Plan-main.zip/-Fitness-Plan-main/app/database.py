from sqlalchemy import create_engine, Column, Integer, String, Text, Float
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

DATABASE_URL = "sqlite:///./fitbuddy.db"
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

class User(Base):
    __tablename__ = "users"
    id           = Column(Integer, primary_key=True, index=True)
    user_id      = Column(String, unique=True, index=True)
    name         = Column(String)
    age          = Column(Integer)
    weight       = Column(Float)
    goal         = Column(String)
    intensity    = Column(String)
    plan         = Column(Text, nullable=True)
    updated_plan = Column(Text, nullable=True)

Base.metadata.create_all(bind=engine)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def save_user(db, user_id, name, age, weight, goal, intensity):
    user = User(user_id=user_id, name=name, age=age, weight=weight, goal=goal, intensity=intensity)
    db.add(user)
    db.commit()
    db.refresh(user)
    return user

def save_plan(db, user_id, plan):
    user = db.query(User).filter(User.user_id == user_id).first()
    if user:
        user.plan = plan
        db.commit()

def update_plan(db, user_id, updated_plan):
    user = db.query(User).filter(User.user_id == user_id).first()
    if user:
        user.updated_plan = updated_plan
        db.commit()

def get_user(db, user_id):
    return db.query(User).filter(User.user_id == user_id).first()

def get_original_plan(db, user_id):
    user = db.query(User).filter(User.user_id == user_id).first()
    return user.plan if user else None

def get_all_users(db):
    return db.query(User).all()
