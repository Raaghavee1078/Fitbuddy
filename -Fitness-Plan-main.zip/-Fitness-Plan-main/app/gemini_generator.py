from google import genai
import os
from dotenv import load_dotenv

load_dotenv()
client = genai.Client(api_key=os.getenv("GOOGLE_API_KEY"))

def generate_workout_gemini(goal: str, intensity: str) -> str:
    prompt = f"""
    Create a structured 7-day workout plan for someone with the following profile:
    - Fitness Goal: {goal}
    - Workout Intensity: {intensity}

    For each day include:
    1. Day title (e.g., Day 1: Upper Body Strength)
    2. Warm-up (5-10 mins) with specific exercises
    3. Main Workout with exercise name, sets, reps/duration
    4. Cooldown or recovery tip

    Format clearly with Day 1, Day 2... headings.
    """
    response = client.models.generate_content(
        model="gemini-2.0-flash", contents=prompt
    )
    return response.text