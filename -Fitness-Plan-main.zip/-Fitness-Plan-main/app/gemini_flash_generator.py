from google import genai
import os
from dotenv import load_dotenv

load_dotenv()
client = genai.Client(api_key=os.getenv("GOOGLE_API_KEY"))

def generate_nutrition_tip_with_flash(goal: str) -> str:
    prompt = f"""
    Give a concise, practical nutrition and recovery tip (under 100 words) for someone 
    whose fitness goal is: {goal}.
    Include advice on hydration, protein intake, or recovery best practices.
    """
    response = client.models.generate_content(
        model="gemini-2.0-flash", contents=prompt
    )
    return response.text